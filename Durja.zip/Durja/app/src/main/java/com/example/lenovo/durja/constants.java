package com.example.lenovo.durja;

public class constants {

    public static final String ROOT_URL;

    static {
        ROOT_URL = "http://192.168.43.136/DURJA/v1/";
    }

    public static final String URL_REGISTER=ROOT_URL+"registeruser.php";
    public static final String URL_LOGIN=ROOT_URL+"registerlogin.php";

}
