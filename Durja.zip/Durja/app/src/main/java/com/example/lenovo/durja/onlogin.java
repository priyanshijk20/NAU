package com.example.lenovo.durja;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import static com.example.lenovo.durja.R.menu.menu;

public class onlogin extends AppCompatActivity {
private TextView name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onlogin);

if(!sharedpreferencemanager.getInstance(this).isloggedin())
{
    finish();
    startActivity(new Intent(this,MainActivity.class));
    return;
}
name=
        (TextView)findViewById(R.id.welcome);
name.setText("WELCOME "+sharedpreferencemanager.getInstance(this).getusername());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.menu,menu);
       return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
      switch
              (item.getItemId())
      {
          case(R.id.menuLogout):
          {
              sharedpreferencemanager.getInstance(this).logout();
              finish();
              startActivity(new Intent(this,MainActivity.class));


              break;}
      }
      return true;
    }
}
