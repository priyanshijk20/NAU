package com.example.lenovo.durja;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public EditText editphoneno,editpassword;
private ProgressDialog progressBar;
    public void login(View view)
    {
        userLogin();

    }
    public void signup(View view) {
        Intent i = new Intent(getApplicationContext(),signup.class);
        startActivity(i);
    }


        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            if(sharedpreferencemanager.getInstance(this).isloggedin())
            {
                finish();
                startActivity(new Intent(this,onlogin.class));
                return;
            }

            editpassword=(EditText)findViewById(R.id.password_login);
        editphoneno=(EditText)findViewById(R.id.phonenumber);
        progressBar =new ProgressDialog(this);
        progressBar.setMessage("please wait..");
        if(sharedpreferencemanager.getInstance(this).isloggedin())
        {
            finish();
            startActivity(new Intent(getApplicationContext(),onlogin.class));
            return;
        }

    }
    public void userLogin()
    {
        final String phoneno=editphoneno.getText().toString().trim();
        final String password=editpassword.getText().toString().trim();
progressBar.show();
        StringRequest stringRequest=new StringRequest(
                Request.Method.POST, "http://192.168.43.136/durja/v1/registerlogin.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressBar.dismiss();

                try {


               JSONObject obj = new JSONObject(response);
                    if(!obj.getBoolean("error")){

                        sharedpreferencemanager.getInstance(getApplicationContext())
                                .userlogin(obj.getInt("id"),
                                        obj.getString("name"),
                                        obj.getString("phoneno"),
                                        obj.getString("address"));

                        {
                        Intent i = new Intent(getApplicationContext(),onlogin.class);
                        startActivity(i);
                    }}
                    else{
                        progressBar.dismiss();
                        Toast.makeText(getApplicationContext(),"error "+obj.getString("message"),Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
progressBar.dismiss();

                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage()+" errors",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ){
            @Override
            protected Map<String,String> getParams() throws AuthFailureError{
                Map<String,String> params=new HashMap<>();

                params.put("phoneno",phoneno);

                params.put("password",password);
                return params;
            }
        };
        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }

}
