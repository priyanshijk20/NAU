package com.example.lenovo.durja;

import android.content.Context;
import android.content.SharedPreferences;

import com.android.volley.RequestQueue;

/**
 * Created by Belal on 26/11/16.
 */

public class sharedpreferencemanager
{
    private static sharedpreferencemanager mInstance;
    private RequestQueue mRequestQueue;
    private static Context mCtx;
    private static final String KEY_SHAREDPREF="MYshraedpref12";
    private static final String KEY_NAME="username";
    private static final String KEY_ADDRESS="useraddress"; private static final String KEY_PHONE="userphoneno";

    private static final String KEY_ID="userid";
    private sharedpreferencemanager(Context context) {
        mCtx = context;

    }

    public static synchronized sharedpreferencemanager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new sharedpreferencemanager(context);
        }
        return mInstance;
    }
public boolean userlogin(int id,String name,String phoneno,String address){
   SharedPreferences sharedpref;
    sharedpref = mCtx.getSharedPreferences(KEY_SHAREDPREF,Context.MODE_PRIVATE);
    SharedPreferences.Editor EDITOR=sharedpref.edit();
    EDITOR.putInt(KEY_ID,id);
    EDITOR.putString(KEY_NAME,name);
    EDITOR.putString(KEY_ADDRESS,address);
    EDITOR.putString(KEY_PHONE,phoneno);
    EDITOR.apply();




    return true;
}
public boolean isloggedin()
{SharedPreferences sharedpref=mCtx.getSharedPreferences(KEY_SHAREDPREF,Context.MODE_PRIVATE);
if( sharedpref.getString(KEY_PHONE,null)!=null) {
    return true;
}
return false;
}

public boolean logout()
{  SharedPreferences sharedpref;
    sharedpref = mCtx.getSharedPreferences(KEY_SHAREDPREF,Context.MODE_PRIVATE);
    SharedPreferences.Editor EDITOR=sharedpref.edit();
    EDITOR.clear();
    EDITOR.apply();
    return true;

}
public String getusername(){
        SharedPreferences sp=mCtx.getSharedPreferences(KEY_SHAREDPREF,Context.MODE_PRIVATE);
        return sp.getString(KEY_NAME,null);
}

}