package com.example.lenovo.durja;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.provider.SyncStateContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;




import org.json.JSONException;
import org.json.JSONObject;

import java.security.PrivateKey;
import java.util.HashMap;
import java.util.Map;

public class signup extends Activity implements View.OnClickListener {
    private EditText editTextname,editTextphoneno,editTextpassword,editTextaddress;
    private Button buttonregister;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        if(sharedpreferencemanager.getInstance(this).isloggedin())
        {
            finish();
            startActivity(new Intent(this,onlogin.class));
            return;
        }

        editTextname=(EditText)findViewById(R.id.name);
   editTextphoneno=(EditText)findViewById(R.id.phoneno);
   editTextaddress=(EditText)findViewById(R.id.address);
   editTextpassword=(EditText)findViewById(R.id.password);
    buttonregister =(Button) findViewById(R.id.signup2);

        progressDialog = new ProgressDialog(this);
buttonregister.setOnClickListener(this);
}
private void registerUser(){

    progressDialog.setMessage("Registering user...");
    progressDialog.show();
    final String name=editTextname.getText().toString().trim();
    final String phoneno=editTextphoneno.getText().toString().trim();
    final String address=editTextaddress.getText().toString().trim();
    final String password=editTextpassword.getText().toString().trim();


    StringRequest stringRequest = new StringRequest(Request.Method.POST,
            constants.URL_REGISTER,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    try {
                        progressDialog.dismiss();
JSONObject json=new JSONObject(response);

                        Toast.makeText(getApplicationContext(), json.getString("message")+" happy", Toast.LENGTH_LONG).show();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.hide();
                    Toast.makeText(getApplicationContext(), error.getMessage()+" error", Toast.LENGTH_LONG).show();
                }
            }) {
        @Override
        protected Map<String,String> getParams() throws AuthFailureError{
            Map<String,String> params=new HashMap<>();
            params.put("name",name);
            params.put("phoneno",phoneno);
            params.put("address",address);
            params.put("password",password);
            return params;
        }
    };
    RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
}

    @Override
    public void onClick(View view) {
        if(view==buttonregister)
            registerUser();
        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
    }

}
